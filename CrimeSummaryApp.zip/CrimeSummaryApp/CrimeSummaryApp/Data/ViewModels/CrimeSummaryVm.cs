﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CrimeSummaryApp.Data.ViewModels
{
    public class CrimeSummaryVm
    {
        public string CrimeCategory { get; set; }
        public decimal OutcomeAvailablePertentage { get; set; }
        public int SumOfOccurrences { get; set; }
    }
}
