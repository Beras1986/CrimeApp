﻿using CrimeSummaryApp.Data.ViewModels;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace CrimeSummaryApp.Data
{
    public class StreetCrimeService
    {
        //private readonly ILogger<StreetCrimeService> _logger;

        //public StreetCrimeService(ILogger<StreetCrimeService> logger)
        //{
        //    _logger = logger;
        //}

        private static readonly HttpClient _client = new();

        public class LastUpdateJsonResponse
        {
            public DateTime date { get; set; }
        }

        public async Task<(bool success, LastUpdateJsonResponse response)> GetLasUpdateDateAsync()
        {
            try
            {
                var response = await _client.GetAsync("https://data.police.uk/api/crime-last-updated");

                if (response.IsSuccessStatusCode)
                {
                    response.EnsureSuccessStatusCode();
                    var responseBody = await response.Content.ReadAsStringAsync();
                    var deserialized = JsonConvert.DeserializeObject<LastUpdateJsonResponse>(responseBody);

                    return (response.IsSuccessStatusCode, deserialized);
                }

                return (false, null);
            }
            catch (Exception ex)
            {
                //_logger.LogError($"Exception caught in {nameof(GetLasUpdateDateAsync)} {ex}.");
                throw;
            }
        }

        public class Street
        {
            public int id { get; set; }
            public string name { get; set; }
        }

        public class Location
        {
            public string latitude { get; set; }
            public Street street { get; set; }
            public string longitude { get; set; }
        }

        public class OutcomeStatus
        {
            public string category { get; set; }
            public string date { get; set; }
        }

        public class CrimeJsonResponse
        {
            public string category { get; set; }
            public string location_type { get; set; }
            public Location location { get; set; }
            public string context { get; set; }
            public OutcomeStatus outcome_status { get; set; }
            public string persistent_id { get; set; }
            public int id { get; set; }
            public string location_subtype { get; set; }
            public string month { get; set; }
        }

        internal async Task<(bool success, List<CrimeJsonResponse> response)> GetSteetCrimeWithinOneMileRadiusAsync(DateTime? date = null, decimal? lat = null, decimal? lng = null)
        {
            try
            {
                var dateString = date.Value.ToString("yyyy-MM");

                var response = await _client.GetAsync($"https://data.police.uk/api/crimes-street/all-crime?lat={lat}&lng={lng}&date={dateString}");

                if (response.IsSuccessStatusCode)
                {
                    response.EnsureSuccessStatusCode();

                    var responseBody = await response.Content.ReadAsStringAsync();

                    var deserialized = JsonConvert.DeserializeObject<List<CrimeJsonResponse>>(responseBody);

                    return (response.IsSuccessStatusCode, deserialized);
                }

                return (false, null);
            }
            catch (Exception ex)
            {
                //_logger.LogError($"Exception caught in {nameof(GetSteetCrimeWithinOneMileRadiusAsync)} {ex}.");
                throw;
            }
        }

        public async Task<List<CrimeSummaryVm>> GetCrimeSummaryAsync(DateTime? date = null, decimal? lat = null, decimal? lng = null)
        {
            try
            {
                if (date.HasValue && lat.HasValue && lng.HasValue)
                {
                    var apiCallResult = await GetSteetCrimeWithinOneMileRadiusAsync(date, lat, lng);

                    if (!apiCallResult.success) return null;

                    var newCrimeSummaryList = new List<CrimeSummaryVm>();

                    if (apiCallResult.response == null || apiCallResult.response.Count == 0)
                    {
                        return newCrimeSummaryList;
                    }

                    foreach(var item in apiCallResult.response)
                    {
                        if (newCrimeSummaryList.Any(x => x.CrimeCategory.Trim() == item.category.Trim()))
                        {
                            var crimeSummary = newCrimeSummaryList.Where(x => x.CrimeCategory.Trim() == item.category.Trim()).FirstOrDefault();

                            var hasOutcomeCount = (int)(crimeSummary.SumOfOccurrences * (crimeSummary.OutcomeAvailablePertentage / 100));

                            if (item.outcome_status != null) hasOutcomeCount += 1;

                            crimeSummary.SumOfOccurrences += 1;

                            crimeSummary.OutcomeAvailablePertentage = (hasOutcomeCount / crimeSummary.SumOfOccurrences) * 100;
                        }
                        else
                        {
                            newCrimeSummaryList.Add(new CrimeSummaryVm
                            {
                                CrimeCategory = item.category.Trim(),
                                SumOfOccurrences = 1,
                                OutcomeAvailablePertentage = item.outcome_status != null ? 100m : 0m
                            });
                        }
                    }

                    return newCrimeSummaryList;
                }

                return null;
            }
            catch (Exception ex)
            {
                //_logger.LogError($"Exception caught in {nameof(GetCrimeSummaryAsync)} {ex}.");
                throw;
            }
        }
    }
}
