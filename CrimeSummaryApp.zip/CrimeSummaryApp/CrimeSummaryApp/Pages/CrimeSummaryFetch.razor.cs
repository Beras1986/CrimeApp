﻿using CrimeSummaryApp.Data;
using CrimeSummaryApp.Data.ViewModels;
using Microsoft.AspNetCore.Components;
using Microsoft.JSInterop;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CrimeSummaryApp.Pages
{
    public partial class CrimeSummaryFetch
    {
        [Inject]
        protected StreetCrimeService CrimeService { get; set; }
        [Inject]
        protected IJSRuntime JSRuntime { get; set; }


        private List<CrimeSummaryVm> _crimeSummaryList;

        private decimal? _lat;

        private decimal? _lng;

        private DateTime? _selectedDate;

        private DateTime? _maximumAllowedDate;

        private bool _doLoadSummary = false;

        private string _dataLoadMessage;

        protected async override Task OnInitializedAsync()
        {
            _lat = null;
            _lng = null;
            _selectedDate = null;

            try
            {
                await JSRuntime.InvokeAsync<bool>("changeTitle", "Crime Cummary");
            }
            catch (Exception ex)
            {
                // do nothing
            }
            
            _crimeSummaryList = new();

            var (success, response) = await CrimeService.GetLasUpdateDateAsync();

            if (success)
            {
                _maximumAllowedDate = response.date.Date;
            }
        }

        private void OnSelectedDateChange(ChangeEventArgs args, bool closedFrom = true)
        {
            if (DateTime.TryParse(args.Value.ToString(), out var dateTime))
            {
               _selectedDate = dateTime;
            }

            StateHasChanged();
        }

        private async Task GetCrimeSummaryAsync()
        {
            _dataLoadMessage = null;
            _doLoadSummary = false;

            if (_lat.HasValue && _lng.HasValue && _selectedDate.HasValue)
            {
                _crimeSummaryList = await CrimeService.GetCrimeSummaryAsync(date: _selectedDate, lat: _lat, lng: _lng);

                if (_crimeSummaryList == null || _crimeSummaryList.Count == 0)
                {
                    _dataLoadMessage = "No data has been retrieved.";
                }
                else
                {
                    _doLoadSummary = true;
                }
            }
            else
            {
                _dataLoadMessage = "Latitude, longitude and date are required.";
            }

            StateHasChanged();
        }
    }
}
