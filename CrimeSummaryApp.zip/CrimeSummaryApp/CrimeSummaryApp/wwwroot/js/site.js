﻿window.changeTitle = function (title) {
    if (title !== null && title.length > 0) {
        document.title = title;
    } else {
        document.title = 'CrimeApp';
    }
    return true;
};