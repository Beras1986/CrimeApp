using CrimeSummaryApp.Data;
using System;
using System.Threading.Tasks;
using Xunit;

namespace CrimeAppTest
{
    [Collection("CrimeServiceRepositoryTests")]
    public class CrimeServiceTests
    {
        [Fact]
        public async Task TestFailLatLngOutsideUKAsync()
        {
            var (latt, lngg) = (48.8566m, 2.2522m);
            var date = DateTime.Now.AddMonths(-6);

            var crimeService = new StreetCrimeService();

            var result = await crimeService.GetCrimeSummaryAsync(date: date, lat: latt, lng: lngg);

            Assert.True(result.Count == 0);

        }

        [Fact]
        public async Task TestSuccessLatLngOutsideUKAsync()
        {
            var date = DateTime.Now.AddMonths(-6);

            var (latt, lngg) = (51.44237m, -2.49810m);

            var crimeService = new StreetCrimeService();

            var result = await crimeService.GetCrimeSummaryAsync(date: date, lat: latt, lng: lngg);

            Assert.False(result.Count == 0);
        }

        [Fact]
        public async Task TestLastUpdatedMethod()
        {
            var crimeService = new StreetCrimeService();

            var result = await crimeService.GetLasUpdateDateAsync();

            Assert.True(result.success);
        }
    }
}
